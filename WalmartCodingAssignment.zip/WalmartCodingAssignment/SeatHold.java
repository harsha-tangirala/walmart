/**
 * @author Harsha Tangirala
 *
 */
package TicketService;

// ********************
// 		IMPORTS
// ********************
import java.util.ArrayList;

public class SeatHold implements TicketService{
	
	public static final int HORIZONTAL_SEATS_COUNT = 33; // 33 were shown in the sample pdf
	public static final int VERTICAL_SEATS_COUNT = 9;    //  9 were shown in the sample pdf
	public static final int TOTAL_VENUE_SEATS = HORIZONTAL_SEATS_COUNT*VERTICAL_SEATS_COUNT;
	
	private int seatHoldID;			// a unique individual ID for each of the seats
	private String customerEmail;	// the customer's email to identify them
	private boolean isHeld;			// to see if the seat is held
	private boolean isReserved;		// to see if the seat is reserved
	private ArrayList<SeatHold> performanceVenue = new ArrayList<SeatHold>(TOTAL_VENUE_SEATS); // The entire performance venue list with all seats
	
	private SeatHold(int anID, String anEmail, boolean aHeld, boolean aReserved) {
		// This individual seats object. It is private because the main method doesn't need to call this
		this.seatHoldID = anID;
		this.customerEmail = anEmail;
		this.isHeld = aHeld;
		this.isReserved = aReserved;
	}
	public SeatHold() {
		// The object to create the entire performance venue with all the seats. 
		// This is public because the main method calls this to create the entire venue theater
		for (int i = 0; i < TOTAL_VENUE_SEATS; i++) {
			this.performanceVenue.add(new SeatHold(i, "", false, false));
		}
	}
	
	/**
	* This method first checks all the available seats in the entire performance venue to see if each seat is
	* neither held not reserved. If they are not, it will increase the counter to tell how many seats are available.
	* @return the number of tickets/ tickets available in the venue
	*/
	@Override
	public int numSeatsAvailable() {
		int availableSeatsCounter = 0; 
		for (int i = 0; i < this.performanceVenue.size(); i++) {
			if ((this.performanceVenue.get(i).isHeld == false) && (this.performanceVenue.get(i).isReserved == false)) {
				availableSeatsCounter = availableSeatsCounter + 1;
			}
		}
		return availableSeatsCounter;		// returns an integer value with all the available seats in the performance venue
	}

	/**
	* The method first checks to see if there are any available seats in the first place. Once that is done, if there are seats
	* available, then it will goes through each individual seat and finds a place for the customer to hold. It does this process until it 
	* holds all the seats the customer asked for. 
	* 
	* ASSUMPTIONS: It is assumed for this particular project that the customer doesn't want seats next to each other. 
	* @param numSeats the number of seats to find and hold
	* @param customerEmail unique identifier for the customer
	* @return a SeatHold object identifying the specific seats and related information
	*/
	@Override
	public SeatHold findAndHoldSeats(int numSeats, String customerEmail) {
		int checkAvailableSeats = 0;
		checkAvailableSeats = this.numSeatsAvailable();		// check if there are seats available in the first place
		
		if (checkAvailableSeats >= numSeats) {	
			for (int i = 0; i < numSeats; i++) {			// assumed that the user doesn't want seats next to each other.
				for (int j = 0; j < this.performanceVenue.size(); j++) {
					if ((this.performanceVenue.get(j).isHeld == false) && (this.performanceVenue.get(j).isReserved == false)) {
						this.performanceVenue.get(j).isHeld = true;
						this.performanceVenue.get(j).customerEmail = customerEmail;
						System.out.println("Customer " + this.performanceVenue.get(j).customerEmail
								+ " is now holding the seat with ID: " + this.performanceVenue.get(j).seatHoldID);
						break;								// get out of this loop
					}
				}
			}
		} else {
			System.out.println("We are sorry " + customerEmail + "! Currently there aren't that many available seats to hold.");
		}
		return null;	// the way my SeatHold object works doesn't return any particular SeatHold object so it is null. 
	}

	/**
	* The method first check to see if the seatHoldId is within the total venue seats available. 
	* Then, it checks that particular seat to see if it has been previously held or reserved, if not, it reserves the seat, but doesn't hold it. 
	* It returns a confirmation code to the user that the seat has been reserved. 
	* 
	* ASSUMPTION: There is isn't a specified format for the confirmation code so the RSVP#seatHoldId format is used.
	*
	* @param seatHoldId the seat hold identifier
	* @param customerEmail the email address of the customer to which the 	seat hold is assigned
	* @return a reservation confirmation code
	*/
	@Override
	public String reserveSeats(int seatHoldId, String customerEmail) {
		String confirmationCode = "";
		if (seatHoldId <= (this.performanceVenue.size() - 1)) {		// check if the seatHoldId is within the venue size range
			if ((this.performanceVenue.get(seatHoldId).isReserved == false) && (this.performanceVenue.get(seatHoldId).isHeld == false)) {
				this.performanceVenue.get(seatHoldId).isReserved = true;
				this.performanceVenue.get(seatHoldId).customerEmail = customerEmail;
				
				confirmationCode = "RSVP#" + seatHoldId;			// RSVP confirmation code format if reservation is a success
			} else {
				confirmationCode = "RSVP#Fail";						// RSVP confirmation code format if reservation is a failure
			}
		} else {
			confirmationCode = "RSVP#Fail";
		}
		return confirmationCode;									// returns whatever RSVP code is determined by previous code
	}

/**
	// This is just a simple test to make sure all the methods are working as intended. 
	public static void main(String[] args) {
		int num = 0; 
		String confirmationCode = "";
		SeatHold GrandArtsVenue = new SeatHold();
		
		// TEST 1: To see how many available seats there are
		num = GrandArtsVenue.numSeatsAvailable();
		System.out.println("Test # 1: To see how many available seats there are \nTotalSeatsAvailable: " + num + "\n");
		
		// TEST 2: To hold more than available seats
		System.out.println("Test # 2: To hold more than available seats (299 seats)");
		GrandArtsVenue.findAndHoldSeats(299, "peter.quill@starlord.com");
		System.out.println();
		
		// Test 3: To hold a certain amount of seats that are available
		System.out.println("Test # 3: To hold a certain amount of seats that are available (5 seats)");
		GrandArtsVenue.findAndHoldSeats(5, "peter.parker@gmail.com");
		num = GrandArtsVenue.numSeatsAvailable();
		System.out.println("TotalSeatsAvailable: " + num + "\n");
		
		// Test 4: To reserve a weird ID/seat number (297 SeatID - Note: ID starts with 0 to 296)
		System.out.println("Test 4: To reserve a weird ID/seat number (297 SeatID - Note: ID starts with 0 to 296)");
		confirmationCode = GrandArtsVenue.reserveSeats(297, "tony.stark@pepperpotts.com");
		System.out.println("Your reservation confirmation code is: " + confirmationCode);
		System.out.println();
		
		// Test 5: To reserve a held seat (SeatID: 0)
		System.out.println("Test 5: To reserve a held seat (SeatID: 0)");
		confirmationCode = GrandArtsVenue.reserveSeats(0, "natasha.romanoff@hotmail.com");
		System.out.println("Your reservation confirmation code is: " + confirmationCode);
		System.out.println();
		
		// Test 6: To reserve an available seat (SeatID: 5)
		System.out.println("Test 6: To reserve an available seat (SeatID: 5)");
		confirmationCode = GrandArtsVenue.reserveSeats(5, "matthew.murdock@aol.com");
		System.out.println("Your reservation confirmation code is: " + confirmationCode);
		System.out.println();
	}
**/

}
