=================
INSTRUCTIONS:
=================

I have included the entire Eclipse Gradle Project folder called "WalmartCoding". 
If you only want the TicketService interface, then they are available in the front page of the folder so you don't have to go into "WalmartCoding" folder.

"TicketService.java" file is the interface that was asked of me to implement.
"SeatHold.java" file is my actual implementation of all the methods asked by the interface. 

My code is commented and I checked to make sure my entire code works. 

=================
ASSUMPTIONS:
=================
Because information given to me is limited, I have assumed the following: 
1. Normally people want to have seats next to each other in the theater, but this coding assignment doesn't specify for me to implement it. If you want me to implement it, I could do that but for the purposes of this assignment, I am just allocating the user request to the first available seat anywhere. 
2. Normally in theaters, the first row is labled as A row, next is B row, and so on. I am just listing my entire venue as a big list. I can separate them by rows if needed but this assignment doesn't specify. 
3. Normally, the first row is high priority/ expensive row for venues that require you to reserve beforehand. If there is such a priority system, I can implement it if needed. 
4. To find out how many seats are in the venue, I am using a 33x9 row x column venue as shown as an example in the pdf with the instructions provided for me to code this assignment. 

=================
GRADLE:
=================
I have never worked with Gradle before so I wasn't sure what to do when the requirement asked me to build with Gradle or Maven. When creating the project in Eclipse, I built it with Gradle option. When I ran my code, it asked me if I wanted to run with Gradle so I did. I have posted a picture of the result as a jpeg file named "GradleResult.jpg

=================
TESTING:
=================
I have done some basic testing to see if my methods work. They can be found in the "SeatHold.java" file. I have commented them out so remove the comments on lines 117 & 157. If you require more testing or specific testing from me, please let me know. 